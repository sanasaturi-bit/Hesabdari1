Hesabdari - Android project (WebView)

1) Install Android Studio (Hedgehog 2023.1.1 or newer) on a computer.
2) File > Open > choose this "Hesabdari" folder. Wait for Gradle sync (needs internet the first time).
   If asked to upgrade the Android Gradle plugin, accept.
3) Build > Build Bundle(s) / APK(s) > Build APK(s).
4) Click "locate" in the popup: app/build/outputs/apk/debug/app-debug.apk
5) Copy the APK to your phone and open it. Allow "install unknown apps" if asked.

Requires Android 10 or newer.
Backups are saved in: Download/Hesabdari
